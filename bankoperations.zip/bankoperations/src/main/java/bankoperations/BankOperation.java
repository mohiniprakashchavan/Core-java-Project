package bankoperations;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BankOperation {
static Connection conn =null;
static PreparedStatement pst =null;
static ResultSet rs = null;
static BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

 void openAccount() throws NumberFormatException, IOException, SQLException {
	try {
	 conn = BankConnection.getConnection();
	System.out.println("Enter Account number ");
	int account_no = Integer.parseInt(br.readLine());
   System.out.println("Enter account  name ");
   String acc_name = br.readLine();
   System.out.println("Enter account type ");
   String acc_type = br.readLine();
   System.out.println("Enter Balance ");
   long balance = Long.parseLong(br.readLine());



String s = "select * from account_details where account_no=?";
pst = conn.prepareStatement(s);
pst.setInt(1,account_no);
rs= pst.executeQuery();
if(!rs.next()) {
	String s1 = "insert into account_details values(?,?,?,?)";
	pst = conn.prepareStatement(s1);
	pst.setInt(1,account_no);
	pst.setString(2, acc_name);
	pst.setString(3,acc_type);
	pst.setLong(4,balance);
	int i = pst.executeUpdate();
	if(i > 0) {
		System.out.println(" Account created! "+"with account number "+account_no);
	}
	else {
		System.out.println("Account not created! ");
	}
}
else {
	System.out.println(account_no+ "sry!already exists");
}
	}catch(Exception e) {
		e.printStackTrace();
	}
	finally {
		conn.close();
		pst.close();
	}
}
 public void Deposite() throws SQLException {
	 try {
	 conn = BankConnection.getConnection();
		System.out.println("Enter Account number ");
		int account_no = Integer.parseInt(br.readLine());
	System.out.println("Enter amount to be deposited ");
	long amt = Long.parseLong(br.readLine());
	String s = "select * from account_details where account_no=?";
	pst = conn.prepareStatement(s);
	pst.setInt(1, account_no);
	rs= pst.executeQuery();
	if(rs.next()) {
		String up = "update account_details set balance = balance + ? where account_no=?";
		pst = conn.prepareStatement(up);
		pst.setLong(1,amt);
		pst.setInt(2,account_no);
	 int i = pst.executeUpdate();
		if(i > 0) {
			System.out.println(" Your ammount deposited sucessfully! ");
		}
		else {
			System.out.println("not deposited ! ");
		}
	}
	else {
		System.out.println(account_no+ "sry!!! Does not exists");
	}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			conn.close();
			pst.close();
		}
	 
 }
 public void withDraw() throws NumberFormatException, IOException, SQLException {
	 try {
	  conn = BankConnection.getConnection();
	 System.out.println("Enter Account number ");
	 int account_no = Integer.parseInt(br.readLine());
		System.out.println("Enter amount to be withdraw ");
		long amt = Long.parseLong(br.readLine()); 
		String ss = "select * from account_details where account_no =?";
		pst = conn.prepareStatement(ss);
		pst.setInt(1, account_no);
		rs = pst.executeQuery();
		if(rs.next()) {
			String depo = "update account_details set balance = balance - ? where account_no=?";
			pst = conn.prepareStatement(depo);
			pst.setLong(1, amt);
			pst.setInt(2, account_no);
			int i =pst.executeUpdate();
			if(i >0) {
				System.out.println(" Your Account is Debited sucessfully! ");
			}
			else {
				System.out.println("Your balance is not sufficient ");
			}
		}
		else {
			System.out.println("sorry! Account doesn't exists");
		}
	 }catch(Exception e){
		 e.printStackTrace();
		 
	 }
	 finally {
		 pst.close();
		 conn.close();
	 }
 }
 public void displayAccountDetails() throws SQLException {
	 try {
	 conn = BankConnection.getConnection();
	 String s = "select * from account_details;";
	 pst = conn.prepareStatement(s);
	 rs = pst.executeQuery();
	 System.out.println("AccountNumber\tAccountName\tAccountType\t   Balance");
	 while(rs.next())
	 {
		 System.out.println(rs.getInt(1)+"\t           "+rs.getString(2)+" \t    "+rs.getString(3)+" \t      "+rs.getLong(4)+"\t   ");
		
	 }
	 
 }
	 catch(Exception e) {
	 e.printStackTrace();
 }
	 finally {
		 pst.close();
		 conn.close();
	 }
 }
 public void deleteRecord() throws SQLException {
	 try {
		  conn = BankConnection.getConnection();
		 System.out.println("Enter Acount number ");
		 int account_no = Integer.parseInt(br.readLine());
			String ss = "select * from account_details where account_no =?";
			pst = conn.prepareStatement(ss);
			pst.setInt(1, account_no);
			rs = pst.executeQuery();
			if(rs.next()) {
				String depo = "delete from account_details where account_no = ?";
				pst = conn.prepareStatement(depo);
				pst.setInt(1, account_no);
				int i =pst.executeUpdate();
				if(i >0) {
					System.out.println(" Your Account deleted! ");
				}
				else {
					System.out.println("Your Account not deactivated ");
				}
			}
			else {
				System.out.println("sorry! Account doesn't exists");
			}
		 }catch(Exception e){
			 e.printStackTrace();
			 
		 }
		 finally {
			 pst.close();
			 conn.close();
		 } 
 }
	public static void main(String[] args) throws NumberFormatException, IOException, SQLException {
		BankOperation obj = new BankOperation();
		while(true) {
			System.out.println("------------------BANK Application---------------------");
			System.out.println("1.Create Account");
			System.out.println("2.Deposite Account");
			System.out.println("3.Withdraw Account");
			System.out.println("4.Display AccountDetails");
			System.out.println("5.Delete Account");
			System.out.println("Enter your choice");
			String name;
			int id;
			int n = Integer.parseInt(br.readLine());
			switch(n) {
			case 1:obj.openAccount();
			break;
			case 2:obj.Deposite();
            break;
			case 3:obj.withDraw();
			break;
			case 4:obj.displayAccountDetails();
			break;
			case 5:obj.deleteRecord();
			break;
	}
            System.out.println("Do you want continue Y/N");
           char ch = br.readLine().toLowerCase().charAt(0);
           if(ch =='n')
         {
            	break;
          }
}
		
}
} 